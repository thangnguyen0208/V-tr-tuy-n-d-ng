# Quản lý đăng ký & phỏng vấn tuyển dụng - Ngành Du lịch / Khách sạn (Đề 7.5)

Spring Boot 3.2 · Spring Web MVC · Spring Data JPA · Spring Security · Thymeleaf · SQL Server · Java 17

## Chạy
1. Mở `sql/schema.sql` trong SSMS/Azure Data Studio và chạy để tạo database `HotelRecruitment`.
2. Sửa `username` / `password` SQL Server trong `src/main/resources/application.properties`.
3. `mvn spring-boot:run` (hoặc chạy `HotelRecruitmentApplication` trong IntelliJ/Eclipse; cần cài plugin Lombok).
4. Mở http://localhost:8080

Tài khoản mẫu: `admin / admin123`, `hr / hr123456`. Ứng viên tự đăng ký tại `/register`.
Dữ liệu mẫu (vị trí, người phỏng vấn) tự nạp lần chạy đầu.

## Quy trình
Nộp hồ sơ → (thi ngoại ngữ nếu chưa có chứng chỉ) → chấm điểm & sàng lọc tự động → xếp lịch vòng 1 (HR)
→ vòng 2 (quản lý bộ phận) → điểm cuối → Trúng tuyển / Dự bị / Không đạt → Nhận việc.

## Thuật toán (service/ScoringService, service/InterviewService)
- Điểm hồ sơ /100: ngoại ngữ 30 + kinh nghiệm 25 + học vấn & chứng chỉ 20 + giao tiếp 10 + sẵn sàng ca/tăng ca 15
- Sàng lọc: ≥70 mời PV | 50–69 danh sách chờ | <50 loại
- Điểm cuối = 40% hồ sơ + 20% ngoại ngữ + 40% phỏng vấn (TB 2 vòng); ≥70 đỗ | 55–69 dự bị | <55 không đạt
- Xếp lịch tự động: slot trống sớm nhất trong 14 ngày, Thứ 2–7, 8–11h & 13–16h, không trùng người phỏng vấn

## Chính sách phí (service/FeeService)
Nộp hồ sơ miễn phí · Thi ngoại ngữ 100.000đ (miễn phí nếu mới ra trường) · Đổi lịch: lần 1 miễn phí, từ lần 2 là 50.000đ
· Đồng phục/thẻ 300.000đ khấu trừ lương tháng đầu · Đăng tin 500.000đ / 1.500.000đ

## Validation
Bean Validation trong `dto/*` (email, SĐT VN, tuổi, miền giá trị) + nghiệp vụ trong `ApplicationService`,
`InterviewService`, `PositionService`: ≥18 tuổi, không nộp trùng, HDV bắt buộc có thẻ, KN & TOEIC tối thiểu theo vị trí,
CV PDF/DOCX ≤5MB, lịch PV ≥24h, không CN, không trùng lịch, quản lý ≥2 năm KN...
