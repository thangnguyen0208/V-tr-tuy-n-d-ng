-- Chay file nay 1 lan trong SSMS / Azure Data Studio truoc khi khoi dong ung dung.
-- Cac bang do Hibernate tu tao (ddl-auto=update), du lieu mau do DataInitializer nap.
IF DB_ID('HotelRecruitment') IS NULL
    CREATE DATABASE HotelRecruitment COLLATE Vietnamese_CI_AS;
GO
