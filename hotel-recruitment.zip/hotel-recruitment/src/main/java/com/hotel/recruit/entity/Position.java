package com.hotel.recruit.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity
@Table(name = "job_position")
@Getter @Setter @NoArgsConstructor
public class Position {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String title;
    private String department;
    @Column(length = 1000)
    private String description;
    private int openings = 1;
    private int minExperience = 0;
    /** 0 = vị trí không yêu cầu ngoại ngữ. */
    private int minToeic = 0;
    private boolean requiresTourGuideCard = false;
    @Enumerated(EnumType.STRING)
    private FeePackage feePackage = FeePackage.STANDARD;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate deadline;
    private boolean active = true;

    public boolean isOpen() {
        return active && deadline != null && !deadline.isBefore(LocalDate.now());
    }

    public long getPostingFee() {
        return feePackage == null ? 0 : feePackage.getFee();
    }
}
