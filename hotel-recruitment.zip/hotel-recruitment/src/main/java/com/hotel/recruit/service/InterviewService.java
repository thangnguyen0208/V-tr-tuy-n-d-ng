package com.hotel.recruit.service;

import com.hotel.recruit.entity.*;
import com.hotel.recruit.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Quy trình phỏng vấn 2 vòng:
 *   Vòng 1 (HR): >= 50 điểm mới được vào vòng 2
 *   Vòng 2 (quản lý bộ phận / thực hành tình huống): tính điểm cuối và ra kết quả
 * Quy tắc xếp lịch: Thứ 2 - Thứ 7, 08:00-11:59 và 13:00-16:59, mỗi buổi 60 phút,
 * cách hiện tại >= 24 giờ, người phỏng vấn không trùng lịch.
 */
@Service
public class InterviewService {
    private static final int[] SLOT_HOURS = {8, 9, 10, 11, 13, 14, 15, 16};

    private final InterviewScheduleRepository scheduleRepo;
    private final InterviewerRepository interviewerRepo;
    private final JobApplicationRepository appRepo;
    private final FeeRecordRepository feeRepo;
    private final ScoringService scoring;
    private final FeeService feeService;

    public InterviewService(InterviewScheduleRepository scheduleRepo, InterviewerRepository interviewerRepo,
                            JobApplicationRepository appRepo, FeeRecordRepository feeRepo,
                            ScoringService scoring, FeeService feeService) {
        this.scheduleRepo = scheduleRepo;
        this.interviewerRepo = interviewerRepo;
        this.appRepo = appRepo;
        this.feeRepo = feeRepo;
        this.scoring = scoring;
        this.feeService = feeService;
    }

    private int nextRound(JobApplication a) {
        if (a.getStatus() == AppStatus.INVITED) return 1;
        if (a.getStatus() == AppStatus.ROUND1_PASSED) return 2;
        throw new BusinessException("Hồ sơ ở trạng thái \"" + a.getStatus().getLabel() + "\" nên không thể xếp lịch phỏng vấn.");
    }

    private void validateSlot(Interviewer iv, LocalDateTime t, Long excludeId, List<String> errors) {
        if (t == null) { errors.add("Vui lòng chọn thời gian phỏng vấn."); return; }
        if (t.isBefore(LocalDateTime.now().plusHours(24)))
            errors.add("Lịch phỏng vấn phải cách thời điểm hiện tại ít nhất 24 giờ.");
        if (t.getDayOfWeek() == DayOfWeek.SUNDAY)
            errors.add("Không xếp phỏng vấn vào Chủ nhật.");
        if (t.getHour() < 8 || t.getHour() > 16 || t.getHour() == 12)
            errors.add("Giờ phỏng vấn hợp lệ: 08:00-11:59 và 13:00-16:59.");
        List<InterviewSchedule> conflicts = scheduleRepo.findByInterviewerAndStatusAndStartTimeBetween(
                iv, ScheduleStatus.SCHEDULED, t.minusMinutes(59), t.plusMinutes(59));
        boolean busy = conflicts.stream().anyMatch(s -> excludeId == null || !s.getId().equals(excludeId));
        if (busy) errors.add("Người phỏng vấn " + iv.getName() + " đã có lịch trong khung giờ này.");
    }

    @Transactional
    public InterviewSchedule schedule(Long appId, Long interviewerId, LocalDateTime time, String location) {
        JobApplication a = appRepo.findById(appId).orElseThrow(() -> new BusinessException("Không tìm thấy hồ sơ."));
        int round = nextRound(a);
        Interviewer iv = interviewerRepo.findById(interviewerId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy người phỏng vấn."));
        List<String> errors = new ArrayList<>();
        if (scheduleRepo.existsByApplicationAndRoundNoAndStatus(a, round, ScheduleStatus.SCHEDULED))
            errors.add("Vòng " + round + " đã có lịch. Hãy dùng chức năng đổi lịch.");
        validateSlot(iv, time, null, errors);
        if (!errors.isEmpty()) throw new BusinessException(errors);
        return create(a, iv, time, location, round);
    }

    /** Thuật toán xếp lịch tự động: slot trống sớm nhất trong 14 ngày tới, thử lần lượt từng người phỏng vấn. */
    @Transactional
    public InterviewSchedule autoSchedule(Long appId, String location) {
        JobApplication a = appRepo.findById(appId).orElseThrow(() -> new BusinessException("Không tìm thấy hồ sơ."));
        int round = nextRound(a);
        if (scheduleRepo.existsByApplicationAndRoundNoAndStatus(a, round, ScheduleStatus.SCHEDULED))
            throw new BusinessException("Vòng " + round + " đã có lịch.");
        List<Interviewer> interviewers = interviewerRepo.findAll();
        if (interviewers.isEmpty()) throw new BusinessException("Chưa có người phỏng vấn nào trong hệ thống.");

        LocalDateTime earliest = LocalDateTime.now().plusHours(24);
        LocalDate start = LocalDate.now().plusDays(1);
        for (int d = 0; d < 14; d++) {
            LocalDate day = start.plusDays(d);
            if (day.getDayOfWeek() == DayOfWeek.SUNDAY) continue;
            for (int h : SLOT_HOURS) {
                LocalDateTime t = day.atTime(h, 0);
                if (t.isBefore(earliest)) continue;
                for (Interviewer iv : interviewers) {
                    List<String> errs = new ArrayList<>();
                    validateSlot(iv, t, null, errs);
                    if (errs.isEmpty()) return create(a, iv, t, location, round);
                }
            }
        }
        throw new BusinessException("Không tìm được khung giờ trống trong 14 ngày tới.");
    }

    private InterviewSchedule create(JobApplication a, Interviewer iv, LocalDateTime t, String location, int round) {
        InterviewSchedule s = new InterviewSchedule();
        s.setApplication(a);
        s.setInterviewer(iv);
        s.setStartTime(t);
        s.setRoundNo(round);
        s.setLocation(location == null || location.isBlank() ? "Phòng họp Nhân sự - Tầng 2" : location.trim());
        return scheduleRepo.save(s);
    }

    /** Ứng viên đổi lịch: lần 1 miễn phí, từ lần 2 thu 50.000đ. */
    @Transactional
    public String reschedule(Long scheduleId, LocalDateTime newTime, AppUser user) {
        InterviewSchedule s = scheduleRepo.findById(scheduleId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy lịch phỏng vấn."));
        if (!s.getApplication().getCandidate().getId().equals(user.getId()))
            throw new BusinessException("Bạn không có quyền đổi lịch này.");
        if (s.getStatus() != ScheduleStatus.SCHEDULED)
            throw new BusinessException("Buổi phỏng vấn này đã hoàn thành.");
        if (s.getStartTime().isBefore(LocalDateTime.now().plusHours(24)))
            throw new BusinessException("Chỉ được đổi lịch trước giờ phỏng vấn ít nhất 24 giờ.");
        List<String> errors = new ArrayList<>();
        validateSlot(s.getInterviewer(), newTime, s.getId(), errors);
        if (!errors.isEmpty()) throw new BusinessException(errors);

        s.setStartTime(newTime);
        s.setRescheduleCount(s.getRescheduleCount() + 1);
        scheduleRepo.save(s);
        long fee = feeService.rescheduleFee(s.getRescheduleCount());
        if (fee > 0) {
            FeeRecord r = new FeeRecord();
            r.setApplication(s.getApplication());
            r.setType(FeeType.RESCHEDULE);
            r.setAmount(fee);
            r.setDescription("Phí đổi lịch phỏng vấn vòng " + s.getRoundNo() + " (lần " + s.getRescheduleCount() + ")");
            feeRepo.save(r);
            return "Đã đổi lịch. Phí đổi lịch lần " + s.getRescheduleCount() + ": " + fee + "đ.";
        }
        return "Đã đổi lịch (miễn phí lần đầu).";
    }

    /** HR nhập điểm phỏng vấn -> chuyển trạng thái / tính điểm cuối. */
    @Transactional
    public void recordResult(Long scheduleId, double score, String note) {
        if (score < 0 || score > 100) throw new BusinessException("Điểm phỏng vấn phải từ 0 đến 100.");
        InterviewSchedule s = scheduleRepo.findById(scheduleId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy lịch phỏng vấn."));
        if (s.getStatus() != ScheduleStatus.SCHEDULED)
            throw new BusinessException("Buổi phỏng vấn đã được chấm điểm.");
        s.setScore(score);
        s.setNote(note);
        s.setStatus(ScheduleStatus.DONE);
        scheduleRepo.save(s);

        JobApplication a = s.getApplication();
        if (s.getRoundNo() == 1) {
            a.setStatus(score >= 50 ? AppStatus.ROUND1_PASSED : AppStatus.FAILED);
        } else {
            double r1 = scheduleRepo.findByApplicationOrderByRoundNoAscStartTimeAsc(a).stream()
                    .filter(x -> x.getRoundNo() == 1 && x.getScore() != null)
                    .mapToDouble(InterviewSchedule::getScore).findFirst().orElse(score);
            scoring.finalizeResult(a, (r1 + score) / 2.0);
        }
        appRepo.save(a);
    }
}
