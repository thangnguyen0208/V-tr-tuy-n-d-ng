package com.hotel.recruit.entity;

public enum DegreeLevel {
    HIGH_SCHOOL("Tốt nghiệp THPT", 6),
    VOCATIONAL("Trung cấp", 10),
    COLLEGE("Cao đẳng", 13),
    UNIVERSITY("Đại học trở lên", 16);

    private final String label;
    private final int points;

    DegreeLevel(String label, int points) { this.label = label; this.points = points; }
    public String getLabel() { return label; }
    public int getPoints() { return points; }
}
