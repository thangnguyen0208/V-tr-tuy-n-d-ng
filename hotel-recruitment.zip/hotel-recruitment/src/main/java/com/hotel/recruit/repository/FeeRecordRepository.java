package com.hotel.recruit.repository;

import com.hotel.recruit.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FeeRecordRepository extends JpaRepository<FeeRecord, Long> {
    List<FeeRecord> findByApplicationOrderByCreatedAtAsc(JobApplication a);

    @Query("select coalesce(sum(f.amount),0) from FeeRecord f where f.type = :type")
    long sumByType(@Param("type") FeeType type);
}
