package com.hotel.recruit.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RegisterForm {
    @NotBlank(message = "Vui lòng nhập tên đăng nhập")
    @Size(min = 4, max = 30, message = "Tên đăng nhập từ 4 đến 30 ký tự")
    @Pattern(regexp = "^[A-Za-z0-9_.]*$", message = "Tên đăng nhập chỉ gồm chữ không dấu, số, _ và .")
    private String username;

    @NotBlank(message = "Vui lòng nhập mật khẩu")
    @Size(min = 6, message = "Mật khẩu tối thiểu 6 ký tự")
    private String password;

    @NotBlank(message = "Vui lòng nhập họ tên")
    private String fullName;

    @NotBlank(message = "Vui lòng nhập email")
    @Email(message = "Email không hợp lệ")
    private String email;

    @NotBlank(message = "Vui lòng nhập số điện thoại")
    @Pattern(regexp = "^(0|\\+84)\\d{9}$", message = "Số điện thoại không hợp lệ")
    private String phone;
}
