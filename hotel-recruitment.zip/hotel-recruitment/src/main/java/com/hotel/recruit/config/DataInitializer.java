package com.hotel.recruit.config;

import com.hotel.recruit.entity.*;
import com.hotel.recruit.repository.InterviewerRepository;
import com.hotel.recruit.repository.PositionRepository;
import com.hotel.recruit.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;

/** Nạp dữ liệu mẫu lần chạy đầu tiên. */
@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seed(UserRepository users, PositionRepository positions,
                           InterviewerRepository interviewers, PasswordEncoder encoder) {
        return args -> {
            if (users.count() == 0) {
                users.save(user("admin", "admin123", "Quản trị viên", Role.ADMIN, encoder));
                users.save(user("hr", "hr123456", "Nhân sự khách sạn", Role.HR, encoder));
            }
            if (positions.count() == 0) {
                LocalDate dl = LocalDate.now().plusMonths(2);
                positions.save(pos("Lễ tân khách sạn", "Front Office", 3, 0, 450, false, FeePackage.FEATURED, dl,
                        "Check-in/out, đón tiếp khách, xử lý đặt phòng. Làm theo ca."));
                positions.save(pos("Nhân viên buồng phòng", "Housekeeping", 5, 0, 0, false, FeePackage.STANDARD, dl,
                        "Vệ sinh, bố trí phòng theo tiêu chuẩn khách sạn."));
                positions.save(pos("Nhân viên phục vụ nhà hàng", "F&B", 4, 0, 0, false, FeePackage.STANDARD, dl,
                        "Phục vụ bàn, order và hỗ trợ khách tại nhà hàng."));
                positions.save(pos("Hướng dẫn viên du lịch", "Tour", 2, 1, 600, true, FeePackage.FEATURED, dl,
                        "Dẫn đoàn nội địa/quốc tế. Bắt buộc có thẻ hướng dẫn viên."));
                positions.save(pos("Điều hành tour", "Tour", 1, 2, 550, false, FeePackage.STANDARD, dl,
                        "Xây dựng chương trình, làm việc với nhà cung cấp và điều phối đoàn."));
                positions.save(pos("Sales du lịch", "Sales", 3, 0, 500, false, FeePackage.STANDARD, dl,
                        "Tư vấn và bán tour, phòng khách sạn cho khách đoàn và khách lẻ."));
                positions.save(pos("Quản lý khách sạn", "Quản lý", 1, 2, 650, false, FeePackage.FEATURED, dl,
                        "Quản lý vận hành, nhân sự và doanh thu khách sạn."));
            }
            if (interviewers.count() == 0) {
                interviewers.save(interviewer("Nguyễn Thị Lan", "Nhân sự", "lan.nt@hotel.local"));
                interviewers.save(interviewer("Trần Minh Quân", "Front Office", "quan.tm@hotel.local"));
                interviewers.save(interviewer("Lê Hoài An", "F&B", "an.lh@hotel.local"));
            }
        };
    }

    private AppUser user(String u, String p, String name, Role r, PasswordEncoder enc) {
        AppUser x = new AppUser();
        x.setUsername(u);
        x.setPassword(enc.encode(p));
        x.setFullName(name);
        x.setRole(r);
        return x;
    }

    private Position pos(String title, String dept, int openings, int exp, int toeic, boolean card,
                         FeePackage pkg, LocalDate dl, String desc) {
        Position p = new Position();
        p.setTitle(title);
        p.setDepartment(dept);
        p.setOpenings(openings);
        p.setMinExperience(exp);
        p.setMinToeic(toeic);
        p.setRequiresTourGuideCard(card);
        p.setFeePackage(pkg);
        p.setDeadline(dl);
        p.setDescription(desc);
        return p;
    }

    private Interviewer interviewer(String name, String dept, String email) {
        Interviewer i = new Interviewer();
        i.setName(name);
        i.setDepartment(dept);
        i.setEmail(email);
        return i;
    }
}
