package com.hotel.recruit.entity;

public enum ScheduleStatus { SCHEDULED, DONE }
