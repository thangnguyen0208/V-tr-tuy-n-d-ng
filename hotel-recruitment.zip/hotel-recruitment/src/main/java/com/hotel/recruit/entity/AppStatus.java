package com.hotel.recruit.entity;

public enum AppStatus {
    SUBMITTED("Đang chờ điểm ngoại ngữ", "secondary"),
    INVITED("Được mời phỏng vấn", "primary"),
    WAITLIST("Danh sách chờ", "warning"),
    REJECTED("Không đạt sàng lọc hồ sơ", "danger"),
    ROUND1_PASSED("Đạt vòng 1 - chờ vòng 2", "info"),
    PASSED("Trúng tuyển", "success"),
    RESERVE("Dự bị", "warning"),
    FAILED("Không đạt", "danger"),
    HIRED("Đã nhận việc (thử việc)", "success");

    private final String label;
    private final String color;

    AppStatus(String label, String color) { this.label = label; this.color = color; }
    public String getLabel() { return label; }
    public String getColor() { return color; }
}
