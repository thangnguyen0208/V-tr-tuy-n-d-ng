package com.hotel.recruit.controller;

import com.hotel.recruit.dto.ApplicationForm;
import com.hotel.recruit.entity.*;
import com.hotel.recruit.repository.*;
import com.hotel.recruit.service.*;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.time.LocalDateTime;

@Controller
public class CandidateController {
    private final PositionRepository positionRepo;
    private final PositionService positionService;
    private final UserRepository userRepo;
    private final JobApplicationRepository appRepo;
    private final InterviewScheduleRepository scheduleRepo;
    private final FeeRecordRepository feeRepo;
    private final ApplicationService applicationService;
    private final InterviewService interviewService;

    public CandidateController(PositionRepository positionRepo, PositionService positionService,
                               UserRepository userRepo, JobApplicationRepository appRepo,
                               InterviewScheduleRepository scheduleRepo, FeeRecordRepository feeRepo,
                               ApplicationService applicationService, InterviewService interviewService) {
        this.positionRepo = positionRepo;
        this.positionService = positionService;
        this.userRepo = userRepo;
        this.appRepo = appRepo;
        this.scheduleRepo = scheduleRepo;
        this.feeRepo = feeRepo;
        this.applicationService = applicationService;
        this.interviewService = interviewService;
    }

    private AppUser current(Principal p) {
        return userRepo.findByUsername(p.getName()).orElseThrow();
    }

    @GetMapping({"/", "/positions"})
    public String positions(Model m) {
        m.addAttribute("positions", positionRepo.findAllByOrderByIdDesc().stream().filter(Position::isOpen).toList());
        return "positions";
    }

    @GetMapping("/apply/{id}")
    public String applyForm(@PathVariable Long id, Model m, Principal principal) {
        AppUser u = current(principal);
        ApplicationForm f = new ApplicationForm();
        f.setFullName(u.getFullName());
        f.setEmail(u.getEmail());
        f.setPhone(u.getPhone());
        fillForm(m, id, f);
        return "apply";
    }

    private void fillForm(Model m, Long id, ApplicationForm f) {
        m.addAttribute("position", positionService.get(id));
        m.addAttribute("form", f);
        m.addAttribute("degrees", DegreeLevel.values());
    }

    @PostMapping("/apply/{id}")
    public String submit(@PathVariable Long id, @Valid @ModelAttribute("form") ApplicationForm form,
                         BindingResult br, Principal principal, Model m, RedirectAttributes ra) {
        if (br.hasErrors()) {
            fillForm(m, id, form);
            return "apply";
        }
        try {
            JobApplication a = applicationService.submit(current(principal), positionService.get(id), form);
            ra.addFlashAttribute("msg", "Nộp hồ sơ thành công. Trạng thái: " + a.getStatus().getLabel());
            return "redirect:/my-applications/" + a.getId();
        } catch (BusinessException e) {
            fillForm(m, id, form);
            m.addAttribute("errors", e.getMessages());
            return "apply";
        }
    }

    @GetMapping("/my-applications")
    public String myApplications(Model m, Principal principal) {
        m.addAttribute("apps", appRepo.findByCandidateOrderBySubmittedAtDesc(current(principal)));
        return "my-applications";
    }

    @GetMapping("/my-applications/{id}")
    public String detail(@PathVariable Long id, Model m, Principal principal) {
        JobApplication a = applicationService.get(id);
        if (!a.getCandidate().getId().equals(current(principal).getId()))
            throw new BusinessException("Bạn không có quyền xem hồ sơ này.");
        m.addAttribute("app", a);
        m.addAttribute("schedules", scheduleRepo.findByApplicationOrderByRoundNoAscStartTimeAsc(a));
        m.addAttribute("fees", feeRepo.findByApplicationOrderByCreatedAtAsc(a));
        return "my-application-detail";
    }

    @PostMapping("/my-applications/schedules/{sid}/reschedule")
    public String reschedule(@PathVariable Long sid,
                             @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime newTime,
                             @RequestParam Long appId, Principal principal, RedirectAttributes ra) {
        try {
            ra.addFlashAttribute("msg", interviewService.reschedule(sid, newTime, current(principal)));
        } catch (BusinessException e) {
            ra.addFlashAttribute("errors", e.getMessages());
        }
        return "redirect:/my-applications/" + appId;
    }

    @ExceptionHandler(BusinessException.class)
    public String handle(BusinessException e, RedirectAttributes ra) {
        ra.addFlashAttribute("errors", e.getMessages());
        return "redirect:/my-applications";
    }
}
