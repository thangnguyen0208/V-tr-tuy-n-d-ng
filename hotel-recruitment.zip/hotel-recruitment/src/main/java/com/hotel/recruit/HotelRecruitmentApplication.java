package com.hotel.recruit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelRecruitmentApplication {
    public static void main(String[] args) {
        SpringApplication.run(HotelRecruitmentApplication.class, args);
    }
}
