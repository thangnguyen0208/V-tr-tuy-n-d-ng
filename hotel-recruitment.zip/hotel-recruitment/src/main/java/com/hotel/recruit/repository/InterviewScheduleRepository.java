package com.hotel.recruit.repository;

import com.hotel.recruit.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface InterviewScheduleRepository extends JpaRepository<InterviewSchedule, Long> {
    List<InterviewSchedule> findByApplicationOrderByRoundNoAscStartTimeAsc(JobApplication a);

    boolean existsByApplicationAndRoundNoAndStatus(JobApplication a, int roundNo, ScheduleStatus status);

    List<InterviewSchedule> findByInterviewerAndStatusAndStartTimeBetween(
            Interviewer i, ScheduleStatus status, LocalDateTime from, LocalDateTime to);
}
