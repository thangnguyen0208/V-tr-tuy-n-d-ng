package com.hotel.recruit.repository;

import com.hotel.recruit.entity.Position;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PositionRepository extends JpaRepository<Position, Long> {
    List<Position> findAllByOrderByIdDesc();
}
