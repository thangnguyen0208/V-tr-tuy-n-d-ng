package com.hotel.recruit.repository;

import com.hotel.recruit.entity.Interviewer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InterviewerRepository extends JpaRepository<Interviewer, Long> { }
