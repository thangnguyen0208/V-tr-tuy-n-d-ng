package com.hotel.recruit.service;

import com.hotel.recruit.entity.Position;
import com.hotel.recruit.repository.PositionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class PositionService {
    private final PositionRepository repo;

    public PositionService(PositionRepository repo) { this.repo = repo; }

    public Position get(Long id) {
        return repo.findById(id).orElseThrow(() -> new BusinessException("Không tìm thấy vị trí tuyển dụng."));
    }

    public Position save(Position p) {
        List<String> errors = new ArrayList<>();
        if (p.getTitle() == null || p.getTitle().isBlank()) errors.add("Vui lòng nhập tên vị trí.");
        if (p.getOpenings() < 1) errors.add("Số lượng tuyển tối thiểu là 1.");
        if (p.getMinExperience() < 0) errors.add("Số năm kinh nghiệm không được âm.");
        if (p.getMinToeic() < 0 || p.getMinToeic() > 990) errors.add("TOEIC tối thiểu từ 0 đến 990.");
        if (p.getDeadline() == null || p.getDeadline().isBefore(LocalDate.now()))
            errors.add("Hạn nộp hồ sơ phải từ hôm nay trở đi.");
        // Quy tắc riêng: vị trí quản lý bắt buộc >= 2 năm kinh nghiệm
        if (p.getTitle() != null && p.getTitle().toLowerCase().contains("quản lý") && p.getMinExperience() < 2)
            errors.add("Vị trí quản lý bắt buộc yêu cầu tối thiểu 2 năm kinh nghiệm.");
        // Quy tắc riêng: Lễ tân / Sales / Hướng dẫn viên bắt buộc có yêu cầu ngoại ngữ
        String t = p.getTitle() == null ? "" : p.getTitle().toLowerCase();
        if ((t.contains("lễ tân") || t.contains("sales") || t.contains("hướng dẫn")) && p.getMinToeic() == 0)
            errors.add("Vị trí lễ tân / sales / hướng dẫn viên bắt buộc đặt yêu cầu ngoại ngữ (TOEIC > 0).");
        if (!errors.isEmpty()) throw new BusinessException(errors);
        return repo.save(p);
    }
}
