package com.hotel.recruit.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "interview_schedule")
@Getter @Setter @NoArgsConstructor
public class InterviewSchedule {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false)
    private JobApplication application;
    @ManyToOne(optional = false)
    private Interviewer interviewer;
    private int roundNo;
    private LocalDateTime startTime;
    private String location;
    @Enumerated(EnumType.STRING)
    private ScheduleStatus status = ScheduleStatus.SCHEDULED;
    private Double score;
    private String note;
    private int rescheduleCount;
}
