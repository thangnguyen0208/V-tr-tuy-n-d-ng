package com.hotel.recruit.controller;

import com.hotel.recruit.dto.RegisterForm;
import com.hotel.recruit.entity.AppUser;
import com.hotel.recruit.entity.Role;
import com.hotel.recruit.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {
    private final UserRepository userRepo;
    private final PasswordEncoder encoder;

    public AuthController(UserRepository userRepo, PasswordEncoder encoder) {
        this.userRepo = userRepo;
        this.encoder = encoder;
    }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/register")
    public String registerForm(Model m) {
        m.addAttribute("form", new RegisterForm());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("form") RegisterForm form, BindingResult br,
                           RedirectAttributes ra) {
        if (!br.hasFieldErrors("username") && userRepo.existsByUsername(form.getUsername()))
            br.rejectValue("username", "dup", "Tên đăng nhập đã tồn tại");
        if (br.hasErrors()) return "register";
        AppUser u = new AppUser();
        u.setUsername(form.getUsername());
        u.setPassword(encoder.encode(form.getPassword()));
        u.setFullName(form.getFullName().trim());
        u.setEmail(form.getEmail());
        u.setPhone(form.getPhone());
        u.setRole(Role.CANDIDATE);
        userRepo.save(u);
        ra.addFlashAttribute("msg", "Đăng ký thành công, hãy đăng nhập.");
        return "redirect:/login";
    }
}
