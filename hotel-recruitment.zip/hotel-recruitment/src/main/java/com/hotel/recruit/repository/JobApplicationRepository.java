package com.hotel.recruit.repository;

import com.hotel.recruit.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface JobApplicationRepository extends JpaRepository<JobApplication, Long> {
    List<JobApplication> findByCandidateOrderBySubmittedAtDesc(AppUser candidate);

    List<JobApplication> findAllByOrderByFinalScoreDescProfileScoreDesc();

    List<JobApplication> findByPositionIdOrderByFinalScoreDescProfileScoreDesc(Long positionId);

    boolean existsByCandidateAndPositionAndStatusNotIn(AppUser c, Position p, Collection<AppStatus> statuses);

    long countByStatus(AppStatus status);
}
