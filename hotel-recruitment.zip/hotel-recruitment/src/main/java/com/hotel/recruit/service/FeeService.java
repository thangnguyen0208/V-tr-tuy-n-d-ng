package com.hotel.recruit.service;

import org.springframework.stereotype.Service;

/**
 * CHÍNH SÁCH PHÍ
 *  - Nộp hồ sơ: miễn phí
 *  - Thi ngoại ngữ tại chỗ: 100.000đ (miễn phí nếu mới ra trường - 0 năm kinh nghiệm)
 *  - Đổi lịch phỏng vấn: lần 1 miễn phí, từ lần 2: 50.000đ/lần
 *  - Đồng phục + thẻ nhân viên: 300.000đ khấu trừ vào lương tháng đầu khi nhận việc
 *  - Phí đăng tin (nhà tuyển dụng): xem FeePackage (500.000đ / 1.500.000đ)
 */
@Service
public class FeeService {
    public static final long LANGUAGE_TEST_FEE = 100_000;
    public static final long RESCHEDULE_FEE = 50_000;
    public static final long UNIFORM_FEE = 300_000;

    public long languageTestFee(int yearsExperience) {
        return yearsExperience == 0 ? 0 : LANGUAGE_TEST_FEE;
    }

    /** @param rescheduleCountAfter số lần đổi lịch tính cả lần vừa đổi */
    public long rescheduleFee(int rescheduleCountAfter) {
        return rescheduleCountAfter <= 1 ? 0 : RESCHEDULE_FEE;
    }
}
