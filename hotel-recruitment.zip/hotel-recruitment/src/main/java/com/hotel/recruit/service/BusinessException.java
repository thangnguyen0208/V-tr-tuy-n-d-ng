package com.hotel.recruit.service;

import java.util.List;

/** Lỗi nghiệp vụ (validation riêng của ngành Du lịch - Khách sạn). */
public class BusinessException extends RuntimeException {
    private final List<String> messages;

    public BusinessException(String message) {
        super(message);
        this.messages = List.of(message);
    }

    public BusinessException(List<String> messages) {
        super(String.join("; ", messages));
        this.messages = messages;
    }

    public List<String> getMessages() { return messages; }
}
