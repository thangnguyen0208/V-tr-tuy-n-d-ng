package com.hotel.recruit.service;

import com.hotel.recruit.dto.ApplicationForm;
import com.hotel.recruit.entity.*;
import com.hotel.recruit.repository.FeeRecordRepository;
import com.hotel.recruit.repository.JobApplicationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

@Service
public class ApplicationService {
    private static final List<AppStatus> CLOSED = List.of(AppStatus.REJECTED, AppStatus.FAILED, AppStatus.HIRED);

    private final JobApplicationRepository appRepo;
    private final FeeRecordRepository feeRepo;
    private final ScoringService scoring;
    private final FeeService feeService;
    private final FileStorageService storage;

    public ApplicationService(JobApplicationRepository appRepo, FeeRecordRepository feeRepo,
                              ScoringService scoring, FeeService feeService, FileStorageService storage) {
        this.appRepo = appRepo;
        this.feeRepo = feeRepo;
        this.scoring = scoring;
        this.feeService = feeService;
        this.storage = storage;
    }

    public JobApplication get(Long id) {
        return appRepo.findById(id).orElseThrow(() -> new BusinessException("Không tìm thấy hồ sơ #" + id));
    }

    /** Bước 1 của quy trình: nộp hồ sơ -> kiểm tra nghiệp vụ -> chấm điểm -> sàng lọc. */
    @Transactional
    public JobApplication submit(AppUser user, Position p, ApplicationForm f) {
        List<String> errors = new ArrayList<>();

        if (!p.isOpen()) errors.add("Vị trí này đã đóng hoặc đã hết hạn nộp hồ sơ.");
        if (f.getBirthDate() != null && Period.between(f.getBirthDate(), LocalDate.now()).getYears() < 18)
            errors.add("Ứng viên phải đủ 18 tuổi trở lên.");
        if (appRepo.existsByCandidateAndPositionAndStatusNotIn(user, p, CLOSED))
            errors.add("Bạn đã nộp hồ sơ cho vị trí này và hồ sơ đang được xử lý.");
        if (p.isRequiresTourGuideCard() && !f.isTourGuideCard())
            errors.add("Vị trí " + p.getTitle() + " bắt buộc có thẻ hướng dẫn viên du lịch.");
        if (f.getYearsExperience() < p.getMinExperience())
            errors.add("Vị trí này yêu cầu tối thiểu " + p.getMinExperience() + " năm kinh nghiệm.");

        if (p.getMinToeic() > 0) {
            if (f.getToeicScore() == null) {
                if (!f.isNeedsLanguageTest())
                    errors.add("Vị trí này yêu cầu ngoại ngữ (TOEIC tối thiểu " + p.getMinToeic()
                            + "): nhập điểm chứng chỉ hoặc đăng ký thi tại chỗ.");
            } else if (f.getToeicScore() < p.getMinToeic()) {
                errors.add("Điểm TOEIC tối thiểu của vị trí này là " + p.getMinToeic() + ".");
            }
        }

        String cvError = storage.validate(f.getCv());
        if (cvError != null) errors.add(cvError);
        if (!errors.isEmpty()) throw new BusinessException(errors);

        JobApplication a = new JobApplication();
        a.setCandidate(user);
        a.setPosition(p);
        a.setFullName(f.getFullName().trim());
        a.setBirthDate(f.getBirthDate());
        a.setPhone(f.getPhone());
        a.setEmail(f.getEmail());
        a.setYearsExperience(f.getYearsExperience());
        a.setToeicScore(f.getToeicScore());
        a.setDegreeLevel(f.getDegreeLevel());
        a.setTourGuideCard(f.isTourGuideCard());
        a.setHospitalityCert(f.isHospitalityCert());
        a.setSoftSkillRating(f.getSoftSkillRating());
        a.setShiftReady(f.isShiftReady());
        a.setNeedsLanguageTest(f.getToeicScore() == null && f.isNeedsLanguageTest());
        a.setCvFileName(storage.save(f.getCv()));
        a.setSubmittedAt(LocalDateTime.now());
        a.setStatus(AppStatus.SUBMITTED);
        appRepo.save(a);

        if (a.isNeedsLanguageTest()) {
            long fee = feeService.languageTestFee(a.getYearsExperience());
            addFee(a, FeeType.LANGUAGE_TEST, fee,
                    fee == 0 ? "Miễn phí thi ngoại ngữ (ứng viên mới ra trường)" : "Phí thi ngoại ngữ tại chỗ");
            // chờ HR nhập điểm ngoại ngữ rồi mới sàng lọc
        } else {
            scoring.screen(a);
        }
        return appRepo.save(a);
    }

    /** HR nhập điểm ngoại ngữ (quy đổi TOEIC) cho ứng viên thi tại chỗ -> sàng lọc. */
    @Transactional
    public void updateLanguageScore(Long id, int score) {
        if (score < 0 || score > 990) throw new BusinessException("Điểm quy đổi TOEIC phải từ 0 đến 990.");
        JobApplication a = get(id);
        if (a.getStatus() != AppStatus.SUBMITTED)
            throw new BusinessException("Hồ sơ không ở trạng thái chờ điểm ngoại ngữ.");
        a.setToeicScore(score);
        if (a.getPosition().getMinToeic() > 0 && score < a.getPosition().getMinToeic()) {
            a.setLanguagePoints(scoring.languagePoints(a));
            a.setProfileScore(scoring.profileScore(a));
            a.setStatus(AppStatus.REJECTED);
        } else {
            scoring.screen(a);
        }
        appRepo.save(a);
    }

    /** HR đưa hồ sơ trong danh sách chờ lên diện được mời phỏng vấn. */
    @Transactional
    public void promoteFromWaitlist(Long id) {
        JobApplication a = get(id);
        if (a.getStatus() != AppStatus.WAITLIST)
            throw new BusinessException("Chỉ hồ sơ trong danh sách chờ mới được nâng lên diện mời phỏng vấn.");
        a.setStatus(AppStatus.INVITED);
        appRepo.save(a);
    }

    /** Bước cuối: nhận việc -> khấu trừ phí đồng phục/thẻ nhân viên. */
    @Transactional
    public void hire(Long id) {
        JobApplication a = get(id);
        if (a.getStatus() != AppStatus.PASSED)
            throw new BusinessException("Chỉ ứng viên trúng tuyển mới được chuyển sang nhận việc.");
        a.setStatus(AppStatus.HIRED);
        appRepo.save(a);
        addFee(a, FeeType.UNIFORM_DEDUCTION, FeeService.UNIFORM_FEE,
                "Khấu trừ đồng phục + thẻ nhân viên vào lương tháng đầu");
    }

    void addFee(JobApplication a, FeeType type, long amount, String desc) {
        FeeRecord r = new FeeRecord();
        r.setApplication(a);
        r.setType(type);
        r.setAmount(amount);
        r.setDescription(desc);
        feeRepo.save(r);
    }
}
