package com.hotel.recruit.entity;

public enum FeeType {
    LANGUAGE_TEST("Phí thi ngoại ngữ"),
    RESCHEDULE("Phí đổi lịch phỏng vấn"),
    UNIFORM_DEDUCTION("Khấu trừ đồng phục/thẻ nhân viên (lương tháng đầu)");

    private final String label;
    FeeType(String label) { this.label = label; }
    public String getLabel() { return label; }
}
