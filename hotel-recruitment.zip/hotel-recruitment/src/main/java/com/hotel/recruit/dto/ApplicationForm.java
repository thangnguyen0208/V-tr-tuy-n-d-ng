package com.hotel.recruit.dto;

import com.hotel.recruit.entity.DegreeLevel;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

@Getter @Setter
public class ApplicationForm {
    @NotBlank(message = "Vui lòng nhập họ tên")
    private String fullName;

    @NotNull(message = "Vui lòng chọn ngày sinh")
    @Past(message = "Ngày sinh phải ở quá khứ")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate birthDate;

    @NotBlank(message = "Vui lòng nhập số điện thoại")
    @Pattern(regexp = "^(0|\\+84)\\d{9}$", message = "Số điện thoại không hợp lệ (VD: 0912345678 hoặc +84912345678)")
    private String phone;

    @NotBlank(message = "Vui lòng nhập email")
    @Email(message = "Email không hợp lệ")
    private String email;

    @Min(value = 0, message = "Số năm kinh nghiệm không được âm")
    @Max(value = 40, message = "Số năm kinh nghiệm không hợp lệ")
    private int yearsExperience;

    @Min(value = 0, message = "Điểm TOEIC từ 0 đến 990")
    @Max(value = 990, message = "Điểm TOEIC từ 0 đến 990")
    private Integer toeicScore;

    @NotNull(message = "Vui lòng chọn trình độ học vấn")
    private DegreeLevel degreeLevel;

    private boolean tourGuideCard;
    private boolean hospitalityCert;

    @Min(value = 1, message = "Tự đánh giá kỹ năng mềm từ 1 đến 5")
    @Max(value = 5, message = "Tự đánh giá kỹ năng mềm từ 1 đến 5")
    private int softSkillRating = 3;

    private boolean shiftReady;
    private boolean needsLanguageTest;

    private MultipartFile cv;
}
