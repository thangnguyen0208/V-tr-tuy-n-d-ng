package com.hotel.recruit.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "job_application")
@Getter @Setter @NoArgsConstructor
public class JobApplication {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false)
    private AppUser candidate;
    @ManyToOne(optional = false)
    private Position position;

    private String fullName;
    private LocalDate birthDate;
    private String phone;
    private String email;
    private int yearsExperience;
    private Integer toeicScore;
    @Enumerated(EnumType.STRING)
    private DegreeLevel degreeLevel;
    private boolean tourGuideCard;
    private boolean hospitalityCert;
    private int softSkillRating;
    private boolean shiftReady;
    private boolean needsLanguageTest;
    private String cvFileName;

    @Enumerated(EnumType.STRING)
    private AppStatus status = AppStatus.SUBMITTED;
    private double languagePoints;
    private double profileScore;
    private Double interviewAvg;
    private Double finalScore;
    private LocalDateTime submittedAt;
}
