package com.hotel.recruit.controller;

import com.hotel.recruit.entity.*;
import com.hotel.recruit.repository.*;
import com.hotel.recruit.service.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/hr")
public class HrController {
    private final JobApplicationRepository appRepo;
    private final PositionRepository positionRepo;
    private final InterviewerRepository interviewerRepo;
    private final InterviewScheduleRepository scheduleRepo;
    private final FeeRecordRepository feeRepo;
    private final ApplicationService applicationService;
    private final InterviewService interviewService;

    public HrController(JobApplicationRepository appRepo, PositionRepository positionRepo,
                        InterviewerRepository interviewerRepo, InterviewScheduleRepository scheduleRepo,
                        FeeRecordRepository feeRepo, ApplicationService applicationService,
                        InterviewService interviewService) {
        this.appRepo = appRepo;
        this.positionRepo = positionRepo;
        this.interviewerRepo = interviewerRepo;
        this.scheduleRepo = scheduleRepo;
        this.feeRepo = feeRepo;
        this.applicationService = applicationService;
        this.interviewService = interviewService;
    }

    @GetMapping("/applications")
    public String list(@RequestParam(required = false) Long positionId, Model m) {
        List<JobApplication> apps = positionId == null
                ? appRepo.findAllByOrderByFinalScoreDescProfileScoreDesc()
                : appRepo.findByPositionIdOrderByFinalScoreDescProfileScoreDesc(positionId);
        m.addAttribute("apps", apps);
        m.addAttribute("positions", positionRepo.findAllByOrderByIdDesc());
        m.addAttribute("positionId", positionId);
        return "hr/applications";
    }

    @GetMapping("/applications/{id}")
    public String detail(@PathVariable Long id, Model m) {
        JobApplication a = applicationService.get(id);
        m.addAttribute("app", a);
        m.addAttribute("schedules", scheduleRepo.findByApplicationOrderByRoundNoAscStartTimeAsc(a));
        m.addAttribute("fees", feeRepo.findByApplicationOrderByCreatedAtAsc(a));
        m.addAttribute("interviewers", interviewerRepo.findAll());
        return "hr/detail";
    }

    @PostMapping("/applications/{id}/language-score")
    public String languageScore(@PathVariable Long id, @RequestParam int score, RedirectAttributes ra) {
        return run(id, ra, "Đã cập nhật điểm ngoại ngữ và sàng lọc hồ sơ.",
                () -> applicationService.updateLanguageScore(id, score));
    }

    @PostMapping("/applications/{id}/promote")
    public String promote(@PathVariable Long id, RedirectAttributes ra) {
        return run(id, ra, "Đã nâng hồ sơ lên diện mời phỏng vấn.", () -> applicationService.promoteFromWaitlist(id));
    }

    @PostMapping("/applications/{id}/schedule")
    public String schedule(@PathVariable Long id, @RequestParam Long interviewerId,
                           @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
                           @RequestParam(required = false) String location, RedirectAttributes ra) {
        return run(id, ra, "Đã xếp lịch phỏng vấn.", () -> interviewService.schedule(id, interviewerId, startTime, location));
    }

    @PostMapping("/applications/{id}/auto-schedule")
    public String autoSchedule(@PathVariable Long id, @RequestParam(required = false) String location,
                               RedirectAttributes ra) {
        return run(id, ra, "Đã tự động xếp lịch vào khung giờ trống sớm nhất.", () -> interviewService.autoSchedule(id, location));
    }

    @PostMapping("/schedules/{sid}/result")
    public String result(@PathVariable Long sid, @RequestParam double score,
                         @RequestParam(required = false) String note, @RequestParam Long appId,
                         RedirectAttributes ra) {
        return run(appId, ra, "Đã ghi nhận điểm phỏng vấn.", () -> interviewService.recordResult(sid, score, note));
    }

    @PostMapping("/applications/{id}/hire")
    public String hire(@PathVariable Long id, RedirectAttributes ra) {
        return run(id, ra, "Đã chuyển ứng viên sang nhận việc.", () -> applicationService.hire(id));
    }

    private String run(Long appId, RedirectAttributes ra, String okMsg, Runnable action) {
        try {
            action.run();
            ra.addFlashAttribute("msg", okMsg);
        } catch (BusinessException e) {
            ra.addFlashAttribute("errors", e.getMessages());
        }
        return "redirect:/hr/applications/" + appId;
    }
}
