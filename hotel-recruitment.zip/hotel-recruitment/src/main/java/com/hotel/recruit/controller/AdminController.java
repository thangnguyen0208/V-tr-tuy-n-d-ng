package com.hotel.recruit.controller;

import com.hotel.recruit.entity.*;
import com.hotel.recruit.repository.*;
import com.hotel.recruit.service.BusinessException;
import com.hotel.recruit.service.PositionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.LinkedHashMap;
import java.util.Map;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final PositionRepository positionRepo;
    private final PositionService positionService;
    private final InterviewerRepository interviewerRepo;
    private final JobApplicationRepository appRepo;
    private final FeeRecordRepository feeRepo;

    public AdminController(PositionRepository positionRepo, PositionService positionService,
                           InterviewerRepository interviewerRepo, JobApplicationRepository appRepo,
                           FeeRecordRepository feeRepo) {
        this.positionRepo = positionRepo;
        this.positionService = positionService;
        this.interviewerRepo = interviewerRepo;
        this.appRepo = appRepo;
        this.feeRepo = feeRepo;
    }

    @GetMapping("/positions")
    public String positions(Model m) {
        m.addAttribute("positions", positionRepo.findAllByOrderByIdDesc());
        return "admin/positions";
    }

    @GetMapping("/positions/new")
    public String newPosition(Model m) {
        m.addAttribute("position", new Position());
        m.addAttribute("packages", FeePackage.values());
        return "admin/position-form";
    }

    @GetMapping("/positions/{id}/edit")
    public String edit(@PathVariable Long id, Model m) {
        m.addAttribute("position", positionService.get(id));
        m.addAttribute("packages", FeePackage.values());
        return "admin/position-form";
    }

    @PostMapping("/positions/save")
    public String save(@ModelAttribute Position position, Model m, RedirectAttributes ra) {
        try {
            positionService.save(position);
            ra.addFlashAttribute("msg", "Đã lưu vị trí tuyển dụng.");
            return "redirect:/admin/positions";
        } catch (BusinessException e) {
            m.addAttribute("errors", e.getMessages());
            m.addAttribute("packages", FeePackage.values());
            return "admin/position-form";
        }
    }

    @PostMapping("/positions/{id}/toggle")
    public String toggle(@PathVariable Long id, RedirectAttributes ra) {
        Position p = positionService.get(id);
        p.setActive(!p.isActive());
        positionRepo.save(p);
        ra.addFlashAttribute("msg", p.isActive() ? "Đã mở lại vị trí." : "Đã đóng vị trí.");
        return "redirect:/admin/positions";
    }

    @GetMapping("/interviewers")
    public String interviewers(Model m) {
        m.addAttribute("interviewers", interviewerRepo.findAll());
        return "admin/interviewers";
    }

    @PostMapping("/interviewers")
    public String addInterviewer(@RequestParam String name, @RequestParam String department,
                                 @RequestParam String email, RedirectAttributes ra) {
        if (name.isBlank() || email.isBlank()) {
            ra.addFlashAttribute("errors", java.util.List.of("Vui lòng nhập tên và email người phỏng vấn."));
        } else {
            Interviewer i = new Interviewer();
            i.setName(name.trim());
            i.setDepartment(department);
            i.setEmail(email.trim());
            interviewerRepo.save(i);
            ra.addFlashAttribute("msg", "Đã thêm người phỏng vấn.");
        }
        return "redirect:/admin/interviewers";
    }

    @GetMapping("/report")
    public String report(Model m) {
        Map<String, Long> byStatus = new LinkedHashMap<>();
        for (AppStatus s : AppStatus.values()) byStatus.put(s.getLabel(), appRepo.countByStatus(s));
        long postingRevenue = positionRepo.findAll().stream().mapToLong(Position::getPostingFee).sum();
        m.addAttribute("byStatus", byStatus);
        m.addAttribute("total", appRepo.count());
        m.addAttribute("postingRevenue", postingRevenue);
        m.addAttribute("languageFees", feeRepo.sumByType(FeeType.LANGUAGE_TEST));
        m.addAttribute("rescheduleFees", feeRepo.sumByType(FeeType.RESCHEDULE));
        m.addAttribute("uniformFees", feeRepo.sumByType(FeeType.UNIFORM_DEDUCTION));
        return "admin/report";
    }
}
