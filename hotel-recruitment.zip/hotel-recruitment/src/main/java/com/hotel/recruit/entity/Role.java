package com.hotel.recruit.entity;

public enum Role { ADMIN, HR, CANDIDATE }
