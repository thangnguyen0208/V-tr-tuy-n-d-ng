package com.hotel.recruit.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "fee_record")
@Getter @Setter @NoArgsConstructor
public class FeeRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false)
    private JobApplication application;
    @Enumerated(EnumType.STRING)
    private FeeType type;
    private long amount;
    private String description;
    private LocalDateTime createdAt = LocalDateTime.now();
}
