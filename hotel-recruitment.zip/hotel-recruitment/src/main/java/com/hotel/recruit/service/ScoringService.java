package com.hotel.recruit.service;

import com.hotel.recruit.entity.AppStatus;
import com.hotel.recruit.entity.JobApplication;
import org.springframework.stereotype.Service;

/**
 * THUẬT TOÁN RIÊNG CỦA NGÀNH DU LỊCH - KHÁCH SẠN
 *
 * Điểm hồ sơ (thang 100):
 *   Ngoại ngữ 30 + Kinh nghiệm ngành 25 + Học vấn/chứng chỉ nghiệp vụ 20
 *   + Kỹ năng giao tiếp (tự đánh giá) 10 + Sẵn sàng làm ca/tăng ca 15
 * Sàng lọc: >= 70 mời phỏng vấn | 50-69 danh sách chờ | < 50 loại
 * Điểm cuối = 40% hồ sơ + 20% ngoại ngữ (quy về thang 100) + 40% phỏng vấn
 * Kết quả:  >= 70 trúng tuyển | 55-69 dự bị | < 55 không đạt
 */
@Service
public class ScoringService {

    public static final double W_PROFILE = 0.4;
    public static final double W_LANGUAGE = 0.2;
    public static final double W_INTERVIEW = 0.4;
    public static final double MAX_LANGUAGE_POINTS = 30;

    public double languagePoints(JobApplication a) {
        Integer t = a.getToeicScore();
        if (t == null) {
            // Vị trí không yêu cầu ngoại ngữ mà không có chứng chỉ -> điểm trung bình 18/30
            return a.getPosition().getMinToeic() == 0 ? 18 : 0;
        }
        if (t >= 800) return 30;
        if (t >= 650) return 24;
        if (t >= 500) return 18;
        if (t >= 350) return 10;
        return 0;
    }

    public double experiencePoints(int years) {
        return Math.min(years, 5) / 5.0 * 25;
    }

    public double qualificationPoints(JobApplication a) {
        double p = a.getDegreeLevel().getPoints();
        if (a.isTourGuideCard() || a.isHospitalityCert()) p += 4;
        return Math.min(p, 20);
    }

    public double profileScore(JobApplication a) {
        double soft = a.getSoftSkillRating() * 2.0;
        double shift = a.isShiftReady() ? 15 : 5;
        double total = a.getLanguagePoints() + experiencePoints(a.getYearsExperience())
                + qualificationPoints(a) + soft + shift;
        return round1(total);
    }

    /** Chấm điểm hồ sơ và sàng lọc tự động. */
    public void screen(JobApplication a) {
        a.setLanguagePoints(languagePoints(a));
        a.setProfileScore(profileScore(a));
        double s = a.getProfileScore();
        if (s >= 70) a.setStatus(AppStatus.INVITED);
        else if (s >= 50) a.setStatus(AppStatus.WAITLIST);
        else a.setStatus(AppStatus.REJECTED);
    }

    /** Tính điểm cuối sau vòng 2 và ra kết quả. */
    public void finalizeResult(JobApplication a, double interviewAvg) {
        double langNorm = a.getLanguagePoints() / MAX_LANGUAGE_POINTS * 100;
        double f = W_PROFILE * a.getProfileScore() + W_LANGUAGE * langNorm + W_INTERVIEW * interviewAvg;
        a.setInterviewAvg(round1(interviewAvg));
        a.setFinalScore(round1(f));
        if (f >= 70) a.setStatus(AppStatus.PASSED);
        else if (f >= 55) a.setStatus(AppStatus.RESERVE);
        else a.setStatus(AppStatus.FAILED);
    }

    private double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
