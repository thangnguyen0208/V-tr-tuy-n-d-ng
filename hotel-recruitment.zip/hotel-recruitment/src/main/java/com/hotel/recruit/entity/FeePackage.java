package com.hotel.recruit.entity;

/** Gói đăng tin tuyển dụng (phí nhà tuyển dụng trả). */
public enum FeePackage {
    STANDARD("Gói thường", 500_000L),
    FEATURED("Gói nổi bật", 1_500_000L);

    private final String label;
    private final long fee;

    FeePackage(String label, long fee) { this.label = label; this.fee = fee; }
    public String getLabel() { return label; }
    public long getFee() { return fee; }
}
