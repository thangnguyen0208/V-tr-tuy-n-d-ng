package com.hotel.recruit.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class FileStorageService {
    @Value("${app.upload-dir}")
    private String uploadDir;

    /** @return thông báo lỗi hoặc null nếu hợp lệ (PDF/DOCX, tối đa 5MB). */
    public String validate(MultipartFile f) {
        if (f == null || f.isEmpty()) return "Vui lòng đính kèm file CV.";
        if (f.getSize() > 5L * 1024 * 1024) return "File CV không được vượt quá 5MB.";
        String name = f.getOriginalFilename() == null ? "" : f.getOriginalFilename().toLowerCase();
        if (!(name.endsWith(".pdf") || name.endsWith(".docx"))) return "File CV chỉ chấp nhận định dạng PDF hoặc DOCX.";
        return null;
    }

    public String save(MultipartFile f) {
        try {
            Path dir = Paths.get(uploadDir);
            Files.createDirectories(dir);
            String name = f.getOriginalFilename().toLowerCase();
            String ext = name.endsWith(".pdf") ? ".pdf" : ".docx";
            String stored = UUID.randomUUID() + ext;
            Files.copy(f.getInputStream(), dir.resolve(stored));
            return stored;
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
